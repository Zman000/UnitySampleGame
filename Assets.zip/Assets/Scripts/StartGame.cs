using UnityEngine;
using UnityEngine.SceneManagement;

public class StartGame : MonoBehaviour
{
   public void StartIt(){
    SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
   }
}
