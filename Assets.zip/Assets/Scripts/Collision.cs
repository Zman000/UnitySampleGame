using UnityEngine;

public class CollisionHandler : MonoBehaviour
{
    public Movement mv;

    void OnCollisionEnter(Collision colInfo)
    {
        if (colInfo.collider.tag == "Obstacle")
        {
            mv.enabled = false;
            GameManager gm = FindFirstObjectByType<GameManager>();
            gm.EndGame();
        }
    }
}