using UnityEngine;
using TMPro;

public class Points : MonoBehaviour
{
    public Transform player;
    public TextMeshProUGUI scoreText;

    void Update()
    {
        scoreText.text = player.position.z.ToString("0"); // Rounded to nearest whole number
    }
}