using UnityEngine;
using UnityEngine.SceneManagement;

public class CompletedLevel : MonoBehaviour
{
    public void LoadNextLevel(){
        Debug.Log("Level2");
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);

    }
}
