using UnityEngine;
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{
    public GameObject completedLevelUI;
    public float restartDelay = 2f;

    public void completedLevel(){
        // Debug.Log("Level finish!");
        completedLevelUI.SetActive(true);
    }

    public void EndGame(){
        Debug.Log("Game over!");
        Invoke("Restart",restartDelay);
        Restart();
    }

    void Restart(){
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
