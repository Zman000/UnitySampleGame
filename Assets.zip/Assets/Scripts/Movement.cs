using UnityEngine;

public class Movement : MonoBehaviour
{
    
    public Rigidbody x;
    public float forwardF = 20;
    public float sdF = 50;
    // public float jumpF = 20;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
        // x.useGravity = false
        // Debug.Log("hello");
    }

    // Update is called once per frame
    void FixedUpdate()
    {   
        x.AddForce(0,0,forwardF * Time.deltaTime,ForceMode.VelocityChange);
        if(Input.GetKey("d")){
            x.AddForce(sdF*Time.deltaTime,0,0,ForceMode.VelocityChange);
        }
        if(Input.GetKey("a")){
            x.AddForce(-sdF*Time.deltaTime,0,0,ForceMode.VelocityChange);
        }
        // if(Input.GetKeyDown("space")){
            // x.AddForce(0,jumpF * Time.deltaTime,0,ForceMode.VelocityChange);
        // }
        
    }
}
